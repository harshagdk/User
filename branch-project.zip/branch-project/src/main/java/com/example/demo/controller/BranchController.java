package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Branch;
import com.example.demo.model.BranchService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class BranchController {
	@Autowired
	private BranchService bs;
	
	@PostMapping("/branch")
	public Branch addBranch(@RequestBody Branch branch)
	{
		return bs.create(branch);
	}
	@GetMapping("/branch")
	public List<Branch> getAllBranches()
	{
		return bs.read();
	}
	@GetMapping("/branch/{bid}")
	public Branch findBranchById(@PathVariable("bid") String bid)
	{
		return bs.read(bid);
	}
	@PutMapping("/branch")
	public Branch modifyBranch(@RequestBody Branch branch)
	{
		return bs.update(branch);
	}
	@DeleteMapping("/branch/{bid}")
	public void removeBranch(@PathVariable("bid")String bid)
	{
		bs.delete(bid);
	}
}

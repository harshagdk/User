package com.mphasis.harsha.demo.model;

public interface UserRepository {

}
